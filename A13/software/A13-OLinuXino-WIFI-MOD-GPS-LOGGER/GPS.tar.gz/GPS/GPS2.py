#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
#       GPS.py
#       
#       Copyright 2013 Stefan Mavrodiev <support@olimex.com>
#       
#       This program is free software; you can redistribute it and/or modify
#       it under the terms of the GNU General Public License as published by
#       the Free Software Foundation; either version 2 of the License, or
#       (at your option) any later version.
#       
#       This program is distributed in the hope that it will be useful,
#       but WITHOUT ANY WARRANTY; without even the implied warranty of
#       MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#       GNU General Public License for more details.
#       
#       You should have received a copy of the GNU General Public License
#       along with this program; if not, write to the Free Software
#       Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
#       MA 02110-1301, USA.
        

import serial
import sys
import time




def main():
    
        
  
   
            
    ser = serial.Serial('/dev/ttyS0', 19200, timeout = None)            
    
    #read the first line of data
    while True:
        line = ser.readline()
        list_s = line.split(',')
        
        if "$GPGGA" == list_s[0]:
            f = open("LOG.txt", 'a+')
            f.write(str(float(list_s[2])/100.0) + "," + str(float(list_s[2])/100.0) + '\n')   
            print("Adding new coordinates...");
            f.close()
	    for i in range(61):
		sys.stdout.write('\r')
		sys.stdout.write("[%-20d] %ds" %('.'*(i*2), i))
		sys.stdout.flush()
		time.sleep(1)
    return
                    

if __name__ == '__main__':
	main()


