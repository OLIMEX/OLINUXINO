<!DOCTYPE html>
<html>
    
    <head>
        <meta name="viewport" content="initial-scale=1.0, user-scalable=no" />
        <script src="jquery-1.9.1.min.js" type="text/javascript"></script>
        <script src="chosen.jquery.js" type="text/javascript"></script>
        <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=YOUR_GOOGLE_MAPS_KEY&sensor=false">
            
        </script>
        <script src="jquery-ui.js" type="text/javascript"></script>
        <style type="text/css">
            html {
                height: 100%
            }
            body {
                height: 100%;
                margin: 0;
                padding: 0
            }
            #map_canvas {
                height: 100%
            }
            #feedback {
                font-size: 1em;
            }
            #selectable .ui-selecting {
                background: #FECA40;
            }
            #selectable .ui-selected {
                background: #F39814;
                color: white;
            }
            #selectable {
                list-style-type: none;
                margin: 0;
                padding: 0;
                width: 100%;
            }
            #selectable li {
                margin: 1px;
                padding: 0em;
                font-size: 1em;
                height: 1.4em;
            }
        </style>
        <script type="text/javascript">
            var crd = [];

            $(function () {
                $("#selectable").selectable({
                    stop: function () {

                        $(".ui-selected", this).each(function () {
                            var index = $("#selectable li").index(this);
                            clearOverlays();
                            codeLatLng(crd[index][0], crd[index][1]);
                        });
                    }
                });
            });


            var geocoder;
            var map;
            var infowindow = new google.maps.InfoWindow();
            var marker;
            var markersArray = [];

            function clearOverlays() {
                for (var i = 0; i < markersArray.length; i++) {
                    markersArray[i].setMap(null);
                }
            }

            function initialize() {
                geocoder = new google.maps.Geocoder();
                var mapOptions = {
                    center: new google.maps.LatLng(42, 24),
                    zoom: 8,
                    mapTypeId: google.maps.MapTypeId.ROADMAP
                };
                map = new google.maps.Map(document.getElementById('map_canvas'), mapOptions);
            }


            function loadScript() {
                var script = document.createElement('script');
                script.type = 'text/javascript';
                script.src = 'https://maps.googleapis.com/maps/api/js?v=3.exp&sensor=false&' +
                    'callback=initialize';
                document.body.appendChild(script);
            }

            window.onload = loadScript;



            function codeLatLng(lat, lng) {
                var latlng = new google.maps.LatLng(lat, lng);
                geocoder.geocode({
                    'latLng': latlng
                }, function (results, status) {
                    if (status == google.maps.GeocoderStatus.OK) {
                        if (results[1]) {
                            map.setCenter(latlng);
                            map.setZoom(15);

                            marker = new google.maps.Marker({
                                position: latlng,
                                map: map,
                                draggable: false,
                                animation: google.maps.Animation.DROP
                            });

                            markersArray.push(marker);

                        } else {
                            alert('No results found');
                        }
                    } else {
                        alert('Geocoder failed due to: ' + status);
                    }
                });
            }

            function loadFile() {
                jQuery.getJSON('x.php', function (data) {
                    var fp = [],
                        key;
                    crd = data;
                    clearOverlays();
                    $('#selectable').html('');
                    for (key = 0; key < data.length; key++) {
                        if (key == (data.length - 1)) {
                            codeLatLng(data[key][0], data[key][1]);
                        }
                        fp[key] = new google.maps.LatLng(data[key][0], data[key][1]);
                        $('#selectable').append($('<li class="ui-widget-content">' + data[key][0] + ',' + data[key][1] + '</li>)'));
                    }

                    var Path = new google.maps.Polyline({
                        path: fp,
                        strokeColor: '#FF0000',
                        strokeOpacity: 1.0,
                        strokeWeight: 2
                    });

                    Path.setMap(map);
                });

            }
        </script>
    </head>
    
    <body onload="initialize()">
        <table border="1" style="width: 100%; height: 90%;">
            <tr>
                <td style="width: 80%;">
                    <div id="map_canvas" style="width: 100%; height: 100%;"></div>
                </td>
                <td style="width: 20%; height: 90%;">
                    <table style="width: 100%; height: 100%; text-align: center; ">
                        <tr style="height: 10%;">
                            <td>
                                <p>Logged coordinates:</p>
                            </td>
                        </tr>
                        <tr style="height: 80%;">
                            <td>
                                <div>
                                    <ol id="selectable" style="text-align: left"></ol>
                                </div>
                            </td>
                        </tr>
                        <tr style="height: 10%;">
                            <td>
                                <input type="button" onclick="loadFile()" style="width: 90%;" value="Load file">
                            </td>
                        </tr>
                    </table>
                </td>
            </tr>
        </table>
    </body>

</html>
