<?php
$a = array();
foreach (file('LOG') as  $line) {
    $b = array();
    foreach (preg_split('/,/', $line) as $x) {
        $b[] = $x + 0;
    }
    
    $a[] = $b;
}

echo json_encode($a, JSON_PRETTY_PRINT);
