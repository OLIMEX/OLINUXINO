#include <jni.h>
#include <string.h>
#include <fcntl.h>
#include <stdlib.h>
#include <unistd.h>
#include "I2C.h"



JNIEXPORT jint JNICALL Java_olimex_a13_ltr501als_I2C_init(JNIEnv *env, jobject obj, jstring file){

	char filename[64];
	const char *name;
	jboolean iscopy;
	const char tag[] = "I2C TEST";

	name = env->GetStringUTFChars(file, &iscopy);
	if(name == NULL){
		LOGE(tag, "Can't get name");
		return -1;
	}

	sprintf(filename, "%s", name);
	LOGI(tag, "Opening \"%s\"...", filename);

	env->ReleaseStringUTFChars(file, name);

	return open(filename, O_RDWR);
}
JNIEXPORT void JNICALL Java_olimex_a13_ltr501als_I2C_close(JNIEnv *env, jobject obj, jint fd){
	if(fd < 0){
		LOGE("close", "Nothing to close!");
	}
	else{
		LOGI("close", "Closing: %d", fd);
		close(fd);
	}
}
JNIEXPORT void JNICALL Java_olimex_a13_ltr501als_I2C_open(JNIEnv *env, jobject obj, jint fd, jint address){
	if(fd < 0){
		LOGE("open", "Nothing to open!");
		return;
	}

	if(address < 0x00 || address > 0xFF){
		LOGE("open", "Invalid address");
		return;
	}

	if(ioctl(fd, I2C_SLAVE_FORCE, address) < 0){
		LOGE("open", "Cannot set device as slave");
		return;
	}
	else{
		LOGI("open", "Opening success");
	}
}
JNIEXPORT void JNICALL Java_olimex_a13_ltr501als_I2C_write(JNIEnv *env, jobject obj, jint fd, jintArray buffer, jint len){
	jboolean isCopy;
	jbyte bufByte[len];
	jint *arr = env->GetIntArrayElements(buffer, &isCopy);
	for(int i = 0 ; i < len; i++){
		LOGI("write", "[%d] %d", i, arr[i]);
		bufByte[i] = arr[i] & 0xFF;
	}
	int result;

	result = write(fd, bufByte, len);
	if(result != len){
		LOGE("write", "Failed sending data");
		LOGE("write", "%d of %d bytes send", result, len);
		return;
	}else{
		LOGI("write", "Sending success");
	}
}
JNIEXPORT jint JNICALL Java_olimex_a13_ltr501als_I2C_read(JNIEnv *env, jobject obj, jint fd, jintArray buffer, jint len){
	jint result;
	unsigned char BufByte[len];
	jint BufInt[len];

	result = read(fd, BufByte, len);
	if(result != len){
		LOGE("read", "Failed to read data");
		return -1;
	}
	for(int i = 0; i < len; i++){
		BufInt[i] = (int)BufByte[i];
	}
	env->SetIntArrayRegion(buffer, 0, len, BufInt);
	LOGI("read", "Read success");
	return result;
}
jint JNI_OnLoad(JavaVM* vm, void* reserverd){
	JNIEnv* env;
	if(vm->GetEnv((void**) &env, JNI_VERSION_1_6) != JNI_OK)
		return -1;

	LOGI("JNI INIT: ", "OK");

	return JNI_VERSION_1_6;

}
