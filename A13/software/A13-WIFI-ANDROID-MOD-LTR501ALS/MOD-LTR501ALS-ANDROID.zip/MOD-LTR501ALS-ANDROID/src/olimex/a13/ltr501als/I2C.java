package olimex.a13.ltr501als;

public class I2C {
	
	public native int init(String bus);
	public native void open(int fd, int address);
	public native void close(int fd);
	public native void write(int fd, int[] buf, int len);
	public native int read(int fd, int[] buf, int len);
	
	static {
		System.loadLibrary("I2C");
	}
	
	
	protected int file_descriptor;

}
