package olimex.a13.ltr501als;

import java.io.IOException;
import java.util.Hashtable;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicBoolean;

import olimex.a20.mod_ltr501als.R;

import android.app.ActionBar;
import android.app.FragmentTransaction;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView.FindListener;
import android.widget.ArrayAdapter;
import android.widget.CompoundButton;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;

public class MainActivity extends FragmentActivity implements
		ActionBar.TabListener {

	/**
	 * The {@link android.support.v4.view.PagerAdapter} that will provide
	 * fragments for each of the sections. We use a
	 * {@link android.support.v4.app.FragmentPagerAdapter} derivative, which
	 * will keep every loaded fragment in memory. If this becomes too memory
	 * intensive, it may be best to switch to a
	 * {@link android.support.v4.app.FragmentStatePagerAdapter}.
	 */
	SectionsPagerAdapter mSectionsPagerAdapter;

	/**
	 * The {@link ViewPager} that will host the section contents.
	 */
	ViewPager mViewPager;
	static String device = "/dev/i2c-2";	
	public static Registers[] regs;
	public static Hashtable<String, Integer> regs_ht;
	

	public static int ReadPS() {
		int value = 0;
		int[] data = new int[2];

		data[0] = regs[regs_ht.get("PS_DATA_0")].ReadRegister();
		data[1] = regs[regs_ht.get("PS_DATA_1")].ReadRegister();

		value = data[1] << 8 | data[0];
		return value;
	}

	public static int ReadALS0() {
		int value = 0;
		int[] data = new int[2];

		data[0] = regs[regs_ht.get("ALS_DATA_CH0_0")].ReadRegister();
		data[1] = regs[regs_ht.get("ALS_DATA_CH0_1")].ReadRegister();

		value = data[1] << 8 | data[0];
		return value;
	}

	public static int ReadALS1() {
		/**
		 * Should be read before ALS0
		 */
		int value = 0;
		int[] data = new int[2];

		data[0] = regs[regs_ht.get("ALS_DATA_CH1_0")].ReadRegister();
		data[1] = regs[regs_ht.get("ALS_DATA_CH1_1")].ReadRegister();

		value = data[1] << 8 | data[0];
		return value;
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		
		
		// Create array of objects
		regs = new Registers[] {
			new Registers("ALS_CONTR", 0x80, 0x00),
			new Registers("PS_CONTR", 0x81, 0x00),
			new Registers("PS_LED", 0x82, 0x6B),
			new Registers("PS_N_PULSES", 0x83, 0x7F),
			new Registers("PS_MEAS_RATE", 0x84, 0x02),
			new Registers("ALS_MEAS_RATE", 0x85, 0x03),
			new Registers("PART_ID", 0x86, 0x80),
			new Registers("MANUFAC_ID", 0x87, 0x05),
			new Registers("ALS_DATA_CH1_0", 0x88, 0x00),
			new Registers("ALS_DATA_CH1_1", 0x89, 0x00),
			new Registers("ALS_DATA_CH0_0", 0x8A, 0x00),
			new Registers("ALS_DATA_CH0_1", 0x8B, 0x00),
			new Registers("ALS_PS_STATUS", 0x8C, 0x00),
			new Registers("PS_DATA_0", 0x8D, 0x00),
			new Registers("PS_DATA_1", 0x8E, 0x00),
			new Registers("INTERRUPT", 0x8F, 0x08),
			new Registers("PS_THRES_UP_0", 0x90, 0xFF),
			new Registers("PS_THRES_UP_1", 0x91, 0x07),
			new Registers("PS_THRES_LOW_0", 0x92, 0x00),
			new Registers("PS_THRES_LOW_1", 0x93, 0x00),
			new Registers("ALS_THRES_UP_0", 0x97, 0xFF),
			new Registers("ALS_THRES_UP_1", 0x98, 0xFF),
			new Registers("ALS_THRES_LOW_0", 0x99, 0x00),
			new Registers("ALS_THRES_LOW_01", 0x99, 0x00),
			new Registers("INTERRUPT_PERSIST", 0x9A, 0x00)
		};
		//Create HashTable
		regs_ht = new Hashtable<String, Integer>();
		Log.i("HASH", "Creating hash table!");
		for(int i = 0; i < regs.length; i++){
			regs_ht.put(regs[i].getName(), i);
			Log.i("HASH", regs[i].getName() + " -> " + i);
		}

		// Gain access to the I2C-devices
		try {
			Runtime.getRuntime().exec(
					new String[] { "su", "-c", "chmod 777 /dev/i2c-*" });
			Log.i("root", "Success chmod.");
		} catch (IOException e) {
			e.printStackTrace();
			Log.e("root", "Fail to gain access");
		}
		

		// Set up the action bar.
		final ActionBar actionBar = getActionBar();
		actionBar.setNavigationMode(ActionBar.NAVIGATION_MODE_TABS);

		// Create the adapter that will return a fragment for each of the three
		// primary sections of the app.
		mSectionsPagerAdapter = new SectionsPagerAdapter(
				getSupportFragmentManager());

		// Set up the ViewPager with the sections adapter.
		mViewPager = (ViewPager) findViewById(R.id.pager);
		mViewPager.setAdapter(mSectionsPagerAdapter);

		// When swiping between different sections, select the corresponding
		// tab. We can also use ActionBar.Tab#select() to do this if we have
		// a reference to the Tab.
		mViewPager
				.setOnPageChangeListener(new ViewPager.SimpleOnPageChangeListener() {
					@Override
					public void onPageSelected(int position) {
						actionBar.setSelectedNavigationItem(position);
					}
				});

		// For each of the sections in the app, add a tab to the action bar.
		for (int i = 0; i < mSectionsPagerAdapter.getCount(); i++) {
			// Create a tab with text corresponding to the page title defined by
			// the adapter. Also specify this Activity object, which implements
			// the TabListener interface, as the callback (listener) for when
			// this tab is selected.
			actionBar.addTab(actionBar.newTab()
					.setText(mSectionsPagerAdapter.getPageTitle(i))
					.setTabListener(this));
		}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public void onTabSelected(ActionBar.Tab tab,
			FragmentTransaction fragmentTransaction) {
		// When the given tab is selected, switch to the corresponding page in
		// the ViewPager.
		mViewPager.setCurrentItem(tab.getPosition());
	}

	@Override
	public void onTabUnselected(ActionBar.Tab tab,
			FragmentTransaction fragmentTransaction) {
	}

	@Override
	public void onTabReselected(ActionBar.Tab tab,
			FragmentTransaction fragmentTransaction) {
	}

	/**
	 * A {@link FragmentPagerAdapter} that returns a fragment corresponding to
	 * one of the sections/tabs/pages.
	 */
	public class SectionsPagerAdapter extends FragmentPagerAdapter {

		public SectionsPagerAdapter(FragmentManager fm) {
			super(fm);
		}

		@Override
		public Fragment getItem(int position) {

			Fragment fragment;
			switch (position) {
			case 0:
				fragment = new MainFragment();
				break;
			case 1:
				fragment = new SettingsFragment();
				break;
			default:
				fragment = null;
			}

			return fragment;
		}

		@Override
		public int getCount() {
			// Show 2 total pages.
			return 2;
		}

		@Override
		public CharSequence getPageTitle(int position) {
			Locale l = Locale.getDefault();
			switch (position) {
			case 0:
				return getString(R.string.title_section1).toUpperCase(l);
			case 1:
				return getString(R.string.title_section2).toUpperCase(l);
			}
			return null;
		}
	}

	public static class SettingsFragment extends Fragment {
		public SettingsFragment() {
		}

		@Override
		public View onCreateView(LayoutInflater inflater, ViewGroup container,
				Bundle savedInstanceState) {
			View rootView = inflater.inflate(R.layout.fragment_settings,
					container, false);
			
			/*
			 * Define spinners
			 */
			Spinner als_gain_spinner = (Spinner) rootView.findViewById(R.id.spinner_als_gain);
			Spinner als_mode_spinner = (Spinner) rootView.findViewById(R.id.spinner_als_mode);
			Spinner ps_gain_spinner = (Spinner) rootView.findViewById(R.id.spinner_ps_gain);
			Spinner ps_mode_spinner = (Spinner) rootView.findViewById(R.id.spinner_ps_mode);
			Spinner led_pulse_spinner = (Spinner) rootView.findViewById(R.id.spinner_led_freq);
			Spinner led_duty_spinner = (Spinner) rootView.findViewById(R.id.spinner_led_duty);
			Spinner led_current_spinner = (Spinner) rootView.findViewById(R.id.spinner_led_current);
			Spinner ps_meas_rate_spinner = (Spinner) rootView.findViewById(R.id.spinner_ps_meas);
			Spinner als_integration_time_spinner = (Spinner) rootView.findViewById(R.id.spinner_als_integration_time);
			Spinner als_meas_rate_spinner = (Spinner) rootView.findViewById(R.id.spinner_als_meas_rate);
			Spinner interrupt_pol_spinner = (Spinner) rootView.findViewById(R.id.spinner_int_pol);
			Spinner interrupt_mode_spinner = (Spinner) rootView.findViewById(R.id.spinner_int_mode);
			
			/*
			 * Define seekbars
			 */
			SeekBar led_pulse_seekbar = (SeekBar) rootView.findViewById(R.id.bar_pulses);
			TextView pulses_text = (TextView) rootView.findViewById(R.id.tx_pulses_bar);
			pulses_text.setText(String.valueOf(led_pulse_seekbar.getProgress()) + " pulses");
			led_pulse_seekbar.setOnSeekBarChangeListener(new MyOnSeekBarChangeListener(pulses_text));
			
			SeekBar als_up_seekbar = (SeekBar) rootView.findViewById(R.id.bar_als_thres_up);
			TextView als_up_text = (TextView) rootView.findViewById(R.id.tx_als_thres_up);
			als_up_text.setText(String.valueOf(als_up_seekbar.getProgress()) + " units");
			als_up_seekbar.setOnSeekBarChangeListener(new MyOnSeekBarChangeListener(als_up_text));
			
			SeekBar als_low_seekbar = (SeekBar) rootView.findViewById(R.id.bar_als_thres_low);
			TextView als_low_text = (TextView) rootView.findViewById(R.id.tx_als_thres_low);
			als_low_text.setText(String.valueOf(als_low_seekbar.getProgress()) + " units");
			als_low_seekbar.setOnSeekBarChangeListener(new MyOnSeekBarChangeListener(als_low_text));
			
			SeekBar ps_up_seekbar = (SeekBar) rootView.findViewById(R.id.bar_ps_thres_up);
			TextView ps_up_text = (TextView) rootView.findViewById(R.id.tx_ps_thres_up);
			ps_up_text.setText(String.valueOf(ps_up_seekbar.getProgress()) + " units");
			ps_up_seekbar.setOnSeekBarChangeListener(new MyOnSeekBarChangeListener(ps_up_text));
			
			SeekBar ps_low_seekbar = (SeekBar) rootView.findViewById(R.id.bar_ps_thres_low);
			TextView ps_low_text = (TextView) rootView.findViewById(R.id.tx_ps_thres_low);
			ps_low_text.setText(String.valueOf(ps_low_seekbar.getProgress()) + " units");
			ps_low_seekbar.setOnSeekBarChangeListener(new MyOnSeekBarChangeListener(ps_low_text));
			
			SeekBar ps_per_seekbar = (SeekBar) rootView.findViewById(R.id.bar_ps_persist);
			TextView ps_per_text = (TextView) rootView.findViewById(R.id.tx_ps_persist);
			ps_per_text.setText(String.valueOf(ps_per_seekbar.getProgress()) + " units");
			ps_per_seekbar.setOnSeekBarChangeListener(new MyOnSeekBarChangeListener(ps_per_text));
			
			SeekBar als_per_seekbar = (SeekBar) rootView.findViewById(R.id.bar_als_persist);
			TextView als_per_text = (TextView) rootView.findViewById(R.id.tx_als_persist);
			als_per_text.setText(String.valueOf(als_per_seekbar.getProgress()) + " units");
			als_per_seekbar.setOnSeekBarChangeListener(new MyOnSeekBarChangeListener(als_per_text));
		
			
			/*
			 * Add listeners
			 */
			als_gain_spinner.setOnItemSelectedListener(new MyOnItemSelectedListener());
			als_mode_spinner.setOnItemSelectedListener(new MyOnItemSelectedListener());
			ps_gain_spinner.setOnItemSelectedListener(new MyOnItemSelectedListener());
			ps_mode_spinner.setOnItemSelectedListener(new MyOnItemSelectedListener());
			led_pulse_spinner.setOnItemSelectedListener(new MyOnItemSelectedListener());
			led_duty_spinner.setOnItemSelectedListener(new MyOnItemSelectedListener());
			led_current_spinner.setOnItemSelectedListener(new MyOnItemSelectedListener());
			ps_meas_rate_spinner.setOnItemSelectedListener(new MyOnItemSelectedListener());
			als_integration_time_spinner.setOnItemSelectedListener(new MyOnItemSelectedListener());
			als_meas_rate_spinner.setOnItemSelectedListener(new MyOnItemSelectedListener());
			interrupt_pol_spinner.setOnItemSelectedListener(new MyOnItemSelectedListener());
			interrupt_mode_spinner.setOnItemSelectedListener(new MyOnItemSelectedListener());
			
			


			return rootView;
		}
	}

	public static class MainFragment extends Fragment {
		public MainFragment() {
		}

		@Override
		public View onCreateView(LayoutInflater inflater, ViewGroup container,
				Bundle savedInstanceState) {
			View rootView = inflater.inflate(R.layout.fragment_main, container,
					false);

			final TextView ps_tv = (TextView) rootView.findViewById(R.id.PS);
			final TextView als0_tv = (TextView) rootView
					.findViewById(R.id.ALS0);
			final TextView als1_tv = (TextView) rootView
					.findViewById(R.id.ALS1);
			final CompoundButton ps_tb = (CompoundButton) rootView
					.findViewById(R.id.switch_ps);
			final CompoundButton als_tb = (CompoundButton) rootView
					.findViewById(R.id.switch_als0);
			final AtomicBoolean terminate_1 = new AtomicBoolean(false);
			final AtomicBoolean terminate_2 = new AtomicBoolean(false);

			final Runnable thread_runnable_ps = new Runnable() {

				@Override
				public void run() {
					try {
						while (!terminate_1.get()) {
							Log.i("PS", String.valueOf(ReadPS()));
							getActivity().runOnUiThread(new Runnable() {

								@Override
								public void run() {
									ps_tv.setText(String.valueOf(ReadPS()));

								}
							});
							Thread.sleep(200);
						}
					} catch (InterruptedException e) {
						Thread.currentThread().interrupt();
					}
				}
			};

			final Runnable thread_runnable_als = new Runnable() {

				@Override
				public void run() {
					try {
						while (!terminate_2.get()) {
							Log.i("ALS0", String.valueOf(ReadALS0()));
							Log.i("ALS1", String.valueOf(ReadALS1()));
							getActivity().runOnUiThread(new Runnable() {

								@Override
								public void run() {
									als0_tv.setText(String.valueOf(ReadALS0()));
									als1_tv.setText(String.valueOf(ReadALS1()));

								}
							});
							Thread.sleep(200);
						}
					} catch (InterruptedException e) {
						Thread.currentThread().interrupt();
					}
				}
			};

			/**
			 * Send Configuration
			 */
			new Thread(new Runnable() {

				@Override
				public void run() {
					int fd;
					int[] conf = new int[7];
					conf[0] = 0x80;
					conf[1] = 0x03;
					conf[2] = 0x03;
					conf[3] = 0x6B;
					conf[4] = 0x7F;
					conf[5] = 0x02;
					conf[6] = 0x03;
					I2C i2c = new I2C();
					fd = i2c.init(device);
					i2c.open(fd, 0x23);
					i2c.write(fd, conf, 7);
					i2c.close(fd);

				}
			}).start();

			ps_tb.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

				@Override
				public void onCheckedChanged(CompoundButton buttonView,
						boolean isChecked) {
					if (isChecked) {
						if (terminate_1.get())
							terminate_1.set(false);
						new Thread(thread_runnable_ps, "Thread_1").start();
					} else {
						terminate_1.set(true);
						ps_tv.setText("OFF");
					}

				}
			});

			als_tb.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

				@Override
				public void onCheckedChanged(CompoundButton buttonView,
						boolean isChecked) {
					if (isChecked) {
						if (terminate_2.get())
							terminate_2.set(false);
						new Thread(thread_runnable_als, "Thread_2").start();
					} else {
						terminate_2.set(true);
						als0_tv.setText("OFF");
						als1_tv.setText("OFF");
					}

				}
			});

			return rootView;
		}
	}
}
