package olimex.a13.ltr501als;


import olimex.a20.mod_ltr501als.R;
import android.graphics.Color;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.TextView;
import android.widget.AdapterView.OnItemSelectedListener;

public class MyOnItemSelectedListener implements OnItemSelectedListener {

	@Override
	public void onItemSelected(AdapterView<?> arg0, View arg1, int arg2,
			long arg3) {
		((TextView)arg0.getChildAt(0)).setTextColor(Color.rgb(255, 255, 255));
		/**
		 * Determine the source
		 */
		String tag;
		int value;
		switch(arg0.getId()){
		
		case R.id.spinner_als_gain:
			tag = "ALS_GAIN";
			value = MainActivity.regs[MainActivity.regs_ht.get("ALS_CONTR")].getValue();
			if(arg2 == 0)
				// Dynamic range 2
				value &= ~0x08;
			else
				// Dynamic Range 1
				value |= 0x08;
			
			MainActivity.regs[MainActivity.regs_ht.get("ALS_CONTR")].setValue(value);
			Log.i(tag, "ALS_CONTR:" + value);
			break;
			
		case R.id.spinner_als_mode:
			tag = "ALS_MODE";
			value = MainActivity.regs[MainActivity.regs_ht.get("ALS_CONTR")].getValue();
			if(arg2 == 0)
				// Standby Mode
				value &= ~0x03;		
			else
				// Active Mode
				value |= 0x03;
			
			MainActivity.regs[MainActivity.regs_ht.get("ALS_CONTR")].setValue(value);
			Log.i(tag, "ALS_CONTR:" + value);
			break;
			
		case R.id.spinner_ps_gain:
			tag = "PS_GAIN";
			value = MainActivity.regs[MainActivity.regs_ht.get("PS_CONTR")].getValue();
			if(arg2 == 0)
				// x1 GAIN
				value &= ~0x0C;
			else if(arg2 == 1){
				// x4 GAIN
				value &= ~0x0C;
				value |= 0x04;
			}else if(arg2 == 2){
				// x8 GAIN
				value &= ~0x0C;
				value |= 0x08;
			}else
				// x16 GAIN
				value |= 0x0C;
			
			MainActivity.regs[MainActivity.regs_ht.get("PS_CONTR")].setValue(value);
			Log.i(tag, "PS_CONTR:" + value);
			break;
			
		case R.id.spinner_ps_mode:
			tag = "PS_MODE";
			value = MainActivity.regs[MainActivity.regs_ht.get("PS_CONTR")].getValue();
			if(arg2 == 0)
				// Standby Mode
				value &= ~0x03;		
			else
				// Active Mode
				value |= 0x03;
			
			MainActivity.regs[MainActivity.regs_ht.get("PS_CONTR")].setValue(value);
			Log.i(tag, "PS_CONTR:" + value);
			break;		
			
		case R.id.spinner_led_freq:
			tag = "LED_FREQ";
			value = MainActivity.regs[MainActivity.regs_ht.get("PS_LED")].getValue();
			if(arg2 == 0)
				// 30kHz
				value &= ~0x0E;
			else if(arg2 == 1){
				//40kHz
				value &= ~0xE0;
				value |= 0x20;
			}else if(arg2 == 2){
				//50kHz
				value &= ~0xE0;
				value |= 0x40;
			}else if(arg2 == 3){
				//60kHz
				value &= ~0xE0;
				value |= 0x60;
			}else if(arg2 == 4){
				//70kHz
				value &= ~0xE0;
				value |= 0x80;
			}else if(arg2 == 5){
				//80kHz
				value &= ~0xE0;
				value |= 0xA0;
			}else if(arg2 == 6){
				//90kHz
				value &= ~0xE0;
				value |= 0xC0;
			}else
				//100kHz
				value |= 0xE0;
	
			
			MainActivity.regs[MainActivity.regs_ht.get("PS_LED")].setValue(value);
			Log.i(tag, "PS_LED:" + value);
			break;			
			
		default:
			break;
		}
		
		

	}

	@Override
	public void onNothingSelected(AdapterView<?> arg0) {
		// TODO Auto-generated method stub

	}

}
