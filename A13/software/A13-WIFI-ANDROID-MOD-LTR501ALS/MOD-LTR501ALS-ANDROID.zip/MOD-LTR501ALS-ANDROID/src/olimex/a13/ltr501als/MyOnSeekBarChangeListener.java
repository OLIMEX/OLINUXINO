/**
 * 
 */
package olimex.a13.ltr501als;

import android.view.View;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.TextView;


public class MyOnSeekBarChangeListener implements OnSeekBarChangeListener {
	
	private TextView text;
	private int progress = 127;
	
	public MyOnSeekBarChangeListener(TextView text){
		this.text = text;
	}

	@Override
	public void onProgressChanged(SeekBar arg0, int arg1, boolean arg2) {
		progress = arg1;
		text.setText(String.valueOf(arg1) + " pulses");
	}


	@Override
	public void onStartTrackingTouch(SeekBar arg0) {

	}

	@Override
	public void onStopTrackingTouch(SeekBar arg0) {
		
	}

}
