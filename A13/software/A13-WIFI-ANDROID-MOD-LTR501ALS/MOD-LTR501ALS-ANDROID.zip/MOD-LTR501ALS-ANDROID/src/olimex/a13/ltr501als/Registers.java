package olimex.a13.ltr501als;

import android.util.Log;

public class Registers {
	/*
	 * Class fields
	 */
	private String name;
	private int value;
	private int address;

	/*
	 * The default constructor
	 */
	public Registers() {
	}

	/*
	 * The other constructor
	 */
	public Registers(String name, int address, int value) {
		this.name = name;
		this.value = value;
		this.address = address;
		Log.i(name, "ADDRESS: " + String.valueOf(this.address) + " VALUE: " + String.valueOf(this.value));
	}

	/*
	 * Access methods
	 */
	public int getValue() {
		return this.value;
	}

	public void setValue(int value) {
		this.value = value;
	}

	public void WriteRegister() {
		I2C i2c = new I2C();
		int fd;
		int[] data = new int[2];
		data[0] = this.address;
		data[1] = this.value;

		fd = i2c.init(MainActivity.device);
		i2c.open(fd, 0x23);
		i2c.write(fd, data, 2);
		i2c.close(fd);
	}

	public int ReadRegister() {
		I2C i2c = new I2C();
		int fd;
		int[] out_data = new int[1];
		int[] in_data = new int[1];

		fd = i2c.init(MainActivity.device);
		i2c.open(fd, 0x23);
		i2c.write(fd, out_data, 1);
		i2c.read(fd, in_data, 1);
		i2c.close(fd);

		return in_data[0];
	}

	public String getName() {
		return this.name;
	}
}
