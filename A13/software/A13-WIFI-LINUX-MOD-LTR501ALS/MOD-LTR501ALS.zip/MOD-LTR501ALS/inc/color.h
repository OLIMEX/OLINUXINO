/*
 * color.h
 *
 *  Created on: Jun 13, 2013
 *      Author: root
 */

#ifndef COLOR_H_
#define COLOR_H_

#define RED		"\033[31m"
#define GREEN	"\033[32m"
#define WHITE	"\033[37m"
#define ESC     "\033[0m"

#endif /* COLOR_H_ */
