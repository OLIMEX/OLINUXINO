/*
 * LTR.c
 *
 * Copyright 2013 Stefan Mavrodiev <support@olimex.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301, USA.
 * 
 */

#define _BSD_SOURCE

#include <stdio.h>
#include <stdlib.h>
#include <getopt.h>
#include <unistd.h>
#include <string.h>
#include <stdint.h>

#include "../inc/color.h"
#include "../inc/i2c.h"


typedef enum{
    ALS_CONTR = 0,
    PS_CONTR,
    PS_LED,
    PS_N_PULSES,
    PS_MEAS_RATE,
    ALS_MEAS_RATE,
    PART_ID,
    MANUFAC_ID,
    ALS_DATA_CH1_0,
    ALS_DATA_CH1_1,
    ALS_DATA_CH0_0,
    ALS_DATA_CH0_1,
    ALS_PS_STATUS,
    PS_DATA_0,
    PS_DATA_1,
    INTERRUPT,
    PS_THRES_UP_0,
    PS_THRES_UP_1,
    PS_THRES_LOW_0,
    PS_THRES_LOW_1,
    ALS_THRES_UP_0,
    ALS_THRES_UP_1,
    ALS_THRES_LOW_0,
    ALS_THRES_LOW_1,
    INTERRUPT_PERSIST,
    COUNT
}index_t;
typedef struct _reg{
    uint8_t value;
    uint8_t default_value;
    uint8_t address;
}registers_t;
 registers_t reg[25] = {
     {0x00, 0x00,   0x80},
     {0x00, 0x00,   0x81},
     {0x6B, 0x6B,   0x82},
     {0x7F, 0x7F,   0x83},
     {0x02, 0x02,   0x84},
     {0x03, 0x03,   0x85},
     {0x80, 0x80,   0x86},
     {0x05, 0x05,   0x87},
     {0x00, 0x00,   0x88},
     {0x00, 0x00,   0x89},
     {0x00, 0x00,   0x8A},
     {0x00, 0x00,   0x8B},
     {0x00, 0x00,   0x8C},
     {0x00, 0x00,   0x8D},
     {0x00, 0x00,   0x8E},
     {0x08, 0x08,   0x8F},
     {0xFF, 0xFF,   0x90},
     {0x07, 0x07,   0x91},
     {0x00, 0x00,   0x92},
     {0x00, 0x00,   0x93},
     {0xFF, 0xFF,   0x97},
     {0xFF, 0xFF,   0x98},
     {0x00, 0x00,   0x99},
     {0x00, 0x00,   0x9A},
     {0x00, 0x00,   0x9E}
 };


const char* program_name;
uint16_t file_descriptor;                         //File descriptor for I2C operations
char* device = "/dev/i2c-2";   
uint8_t SlaveAddress = 0x23;
int _Read = 0;
int _Cont = 0;

int16_t Write_Register(index_t index);
int16_t Read_Register(index_t index);
int16_t CheckID(void);
void SendConfiguration(void);

void SendConfiguration(void){
    
    
    /* PS_THRES_UP_0 */
    if(_DEBUG)
        printf("Sending PS_THRES_UP_0(0x%02X)...[ %sOK%s ]\n", reg[PS_THRES_UP_0].value, GREEN, ESC);
    Write_Register(PS_THRES_UP_0);
    
    /* PS_THRES_UP_1 */
    if(_DEBUG)
        printf("Sending PS_THRES_UP_1(0x%02X)...[ %sOK%s ]\n", reg[PS_THRES_UP_1].value, GREEN, ESC);
    Write_Register(PS_THRES_UP_1);
    
    /* PS_THRES_LOW_0*/
    if(_DEBUG)
        printf("Sending PS_THRES_LOW_0(0x%02X)...[ %sOK%s ]\n", reg[PS_THRES_LOW_0].value, GREEN, ESC);
    Write_Register(PS_THRES_LOW_0);
    
    /* PS_THRES_LOW_1 */
    if(_DEBUG)
        printf("Sending PS_THRES_LOW_1(0x%02X)...[ %sOK%s ]\n", reg[PS_THRES_LOW_1].value, GREEN, ESC);
    Write_Register(PS_THRES_LOW_1);
    
    /* ALS_THRES_UP_0 */
    if(_DEBUG)
        printf("Sending ALS_THRES_UP_0(0x%02X)...[ %sOK%s ]\n", reg[ALS_THRES_UP_0].value, GREEN, ESC);
    Write_Register(ALS_THRES_UP_0);
    
    /* ALS_THRES_UP_1 */
    if(_DEBUG)
        printf("Sending ALS_THRES_UP_1(0x%02X)...[ %sOK%s ]\n", reg[ALS_THRES_UP_1].value, GREEN, ESC);
    Write_Register(ALS_THRES_UP_1);
    
    /* ALS_THRES_LOW_0*/
    if(_DEBUG)
        printf("Sending ALS_THRES_LOW_0(0x%02X)...[ %sOK%s ]\n", reg[ALS_THRES_LOW_0].value, GREEN, ESC);
    Write_Register(ALS_THRES_LOW_0);
    
    /* ALS_THRES_LOW_1 */
    if(_DEBUG)
        printf("Sending ALS_THRES_LOW_1(0x%02X)...[ %sOK%s ]\n", reg[ALS_THRES_LOW_1].value, GREEN, ESC);
    Write_Register(ALS_THRES_LOW_1);
    
    /* INTERRUPT */
    if(_DEBUG)
        printf("Sending INTERRUPT(0x%02X)...[ %sOK%s ]\n", reg[INTERRUPT].value, GREEN, ESC);
    Write_Register(INTERRUPT);
    
    /* INTERRUPT_PERSIST */
    if(_DEBUG)
        printf("Sending INTERRUPT_PERSIST(0x%02X)...[ %sOK%s ]\n", reg[INTERRUPT_PERSIST].value, GREEN, ESC);
    Write_Register(INTERRUPT_PERSIST);
    
    /* ALS_CONTR */
    if(_DEBUG)
        printf("Sending ALS_CONTR(0x%02X)...[ %sOK%s ]\n", reg[ALS_CONTR].value, GREEN, ESC);
    Write_Register(ALS_CONTR);
    
    /* PS_CONTR */
    if(_DEBUG)
        printf("Sending PS_CONTR(0x%02X)...[ %sOK%s ]\n", reg[PS_CONTR].value, GREEN, ESC);
    Write_Register(PS_CONTR);
    
    /* PS_LED */
     if(_DEBUG)
        printf("Sending PS_LED(0x%02X)...[ %sOK%s ]\n", reg[PS_LED].value, GREEN, ESC);
    Write_Register(PS_LED);
    
    /* PS_N_PULSES */
     if(_DEBUG)
        printf("Sending PS_N_PULSES(0x%02X)...[ %sOK%s ]\n", reg[PS_N_PULSES].value, GREEN, ESC);
    Write_Register(PS_N_PULSES);
    
    /* PS_MEAS_RATE */
    if(_DEBUG)
        printf("Sending PS_MEAS_RATE(0x%02X)...[ %sOK%s ]\n", reg[PS_MEAS_RATE].value, GREEN, ESC);
    Write_Register(PS_MEAS_RATE);
    
    /* ALS_MEAS_RATE */
    if(_DEBUG)
        printf("Sending ALS_MEAS_RATE(0x%02X)...[ %sOK%s ]\n", reg[ALS_MEAS_RATE].value, GREEN, ESC);
    Write_Register(ALS_MEAS_RATE);

}
int16_t CheckID(void){
    if(Read_Register(PART_ID) == 0 && Read_Register(MANUFAC_ID) == 0){
        /*
         * Check Chip ID
         */
        if(_DEBUG)
            printf("PART ID: 0x%02X ... ", reg[PART_ID].value);
        if(reg[PART_ID].value == reg[PART_ID].default_value){
            if(_DEBUG)
                printf("[ %sOK%s ]\n", GREEN, ESC);
        }else{
            if(_DEBUG)
                printf("[ %sFAIL%s ]\n", RED, ESC);
            return -1;
        }
        /*
         * Check Manufactor ID
         */
        if(_DEBUG)
        printf("PART ID: 0x%02X ... ", reg[MANUFAC_ID].value);
        if(reg[MANUFAC_ID].value == reg[MANUFAC_ID].default_value){
            if(_DEBUG)
                printf("[ %sOK%s ]\n", GREEN, ESC);
            return 0;
        }else{
            if(_DEBUG)
                printf("[ %sFAIL%s ]\n", RED, ESC);
            return -1;
        }
        
    }else{
        printf("Failed to check id!\n");
        return -1;
    }
}
int16_t Write_Register(index_t index){
    /*
     * Set data to coresponding field of reg struct.
     * After that the this register is writen to the device.
     * If there is error -1 is returned. Otherwise - 0.
     */
     uint8_t out_buffer[2];
     out_buffer[0] = reg[index].address;
     out_buffer[1] = reg[index].value;
     if(I2C_Open(&file_descriptor, device, SlaveAddress) != 0){
         printf("Failed to open I2C bus!\n");
         printf("Check --i2c option.\n");
         return -1;
     }
     if(I2C_Send(&file_descriptor, out_buffer, 2) != 0){
        printf("Failed to send data!\n");
        printf("Check if --address is set correctly.\n");
        return -1;
     }
     I2C_Close(&file_descriptor);
     return 0;
}
int16_t Read_Register(index_t index){
    /*
     * Read data from selected register. The readed value
     * is writen to reg[] array. On ERROR return -1.
     */
     uint8_t out_buffer[1];
     uint8_t in_buffer[1];
     
     out_buffer[0] = reg[index].address;
     
     if(I2C_Open(&file_descriptor, device, SlaveAddress) != 0){
         printf("Failed to open I2C bus!\n");
         printf("Check --i2c option.\n");
         exit(-1);
     }
     if(I2C_Send(&file_descriptor, out_buffer, 1) != 0){
        printf("Failed to send data!\n");
        printf("Check if --address is set correctly.\n");
        exit(-1);
     }
     if(I2C_Read(&file_descriptor, in_buffer, 1) != 0){
        printf("Failed to read data!\n");
        printf("Check if --address is set correctly.\n");
        exit(-1);
     }
     reg[index].value = in_buffer[0];
     I2C_Close(&file_descriptor);
     return 0;
}

void print_usage (int16_t exit_code){
    printf("Usage: %s option [PARAMETERS]\n", program_name);
    printf( "DESCRIPTION\n"
            "               The LTR-501ALS is an integrated I2C digital light sensor [ALS] and proximity sensor [PS]\n"
            "               with built-in LED driver, in a miniature chipled lead-free surface mount package. This\n"
            "               device converts light intensity to a digital output signal capable of direct I2C \n"
            "               interface. It provides a linear response over a wide dynamic range from 0.01 lux to \n"
            "               64k lux and is well suited to applications under high ambient brightness. With built-in\n"
            "               proximity sensor, LTR-501ALS offers the feature to detect object at a user cofigurable\n"
            "               distance up to 10cm."
            "OPTIONS\n"
            "   -h  --help              Display this usage information.\n"
            "   -v  --verbose           Set verbose mode.\n"
            "   -i  --i2c               Select I2C-bus to use.\n"
            "   -a  --address           Slave address, default 0x23.\n"
            "       --continuously      Read the value in data registers, until ^C is pressed\n"
            "LIGHT SENSOR OPTIONS\n"
            "       --als-gain          Select dynamic range:\n"
            "                           \"1\" - Range 1(0.01 lux to 320 lux),\n"
            "                           \"0\" - Range 2(2 lux to 64k lux).\n"
            "       --als-mode          Select operation mode:\n"
            "                           \"STANDBY\" - ALS module is not started,\n"
            "                           \"ACTIVE\"  - Start ALS module, enable by default.\n"
            "       --als-integration-time  Integration time is the measurement time for each ALS cycle:\n"
            "                               \"100\" - 100ms (default),\n"
            "                               \"50\" - 50ms (can only be used in Dynamic Range 2, effective resolution\n"
            "                               is 15bit @ 2 lux/count)\n"
            "                               \"200\" - 200ms (can only be used in Dynamic Range 1)\n"
            "                               \"400\" - 400ms (can only be used in Dynamic Range 1)\n"
            "       --als-measurement-rate  ALS Measurement Repeat Rate is the interval btween ALS_DATA registers\n"
            "                               update. Must be set to be equal or larger than the ALS Integration Time.\n"
            "                               If ALS Measurement Repeat Rate is set to be smaller than ALS Integration\n"
            "                               Time, it will automatically be reset to be equal to ALS Integration Time\n"
            "                               by the IC internally.\n"
            "                               \"50\" - 50ms,\n"
            "                               \"100\" - 100ms,\n"
            "                               \"200\" - 200ms,\n"
            "                               \"500\" - 500ms (default),\n"
            "                               \"1000\" - 1000ms,\n"
            "                               \"2000\" - 2000ms.\n"
            "PROXIMITY SENSOR OPTIONS\n"
            "       --ps-gain           Select gain for PS sensor:\n"
            "                           \"1\" - x1 Gain (default),\n"
            "                           \"4\" - x4 Gain,\n"
            "                           \"8\" - x8 Gain,\n"
            "                           \"16\" - x16 Gain.\n"
            "       --ps-mode           Select operation mode:\n"
            "                           \"STANDBY\" - PS is not running,\n"
            "                           \"ACTIVE\" - PS is started.\n"
            "       --ps-led-freq       Select pulse frequency for the LED:\n"
            "                           \"30\" - 30kHz,\n"
            "                           \"40\" - 40kHz,\n"
            "                           \"50\" - 50kHz,\n"
            "                           \"60\" - 60kHz (default),\n"
            "                           \"70\" - 70kHz,\n"
            "                           \"80\" - 80kHz,\n"
            "                           \"90\" - 90kHz,\n"
            "                           \"100\" - 100kHz.\n"
            "       --ps-led-duty       Select duty cycle for the LED:\n"
            "                           \"25\" - 25%%,\n"
            "                           \"50\" - 50%% (default),\n"
            "                           \"75\" - 75%%,\n"
            "                           \"100\" - 100%%.\n"
            "       --ps-led-current    Define LED Peak Current:\n"
            "                           \"5\" - 5mA,\n"
            "                           \"10\" - 10mA,\n"
            "                           \"20\" - 20mA,\n"
            "                           \"50\" - 50mA (default),\n"
            "                           \"100\" - 100mA.\n"
            "       --ps-led-pulses     Set LED Pulse Count. Range is from 0 to 255\n"
            "       --ps-measurement-rate   Control the timing of the periodic measurements of the PS in active\n"
            "                               mode. PS Measurement Repeat Rate is the interval between PS_DATA\n"
            "                               registers update:\n"
            "                               \"50\" - 50ms,\n"
            "                               \"70\" - 70ms,\n"
            "                               \"100\" - 100ms (default),\n"
            "                               \"200\" - 200ms,\n"
            "                               \"500\" - 500ms,\n"
            "                               \"1000\" - 1000ms,\n"
            "                               \"2000\" - 2000ms.\n"
            "INTERRUPT OPTIONS\n"
            "                           The INTERRUPT reguster controls the operation of the interrupt pin and\n"
            "                           functions. When the Interrupt Mode is set to inactive, the INT output pin 2\n"
            "                           is inactive/disabled and will no trigger any interrupt. However at this\n"
            "                           condition, the ALS_PS_STATUS register will still be updated.\n"
            "                           Note that when this register is to be set with values other that its\n"
            "                           default values, it should be set before device is in Active mode.\n"
            "       --int-polarity      Set polarity of the INT pin:\n"
            "                           \"0\" - INT output pin 2 is considered active when it is a logic 0(default),\n"
            "                           \"1\" - INT output pin 2 is considered active when it is a logic 1.\n"
            "       --int-mode          Set interrupt mode:\n"
            "                           \"NONE\" - INT output pin 2 is high impodance state (default),\n"
            "                           \"PS\" - Only PS measurement can trigger interrupt,\n"
            "                           \"ALS\" - Only ALS measurement can trigger interrupt,\n"
            "                           \"BOTH\" - Both ALS and PS measurement can trigger interrupt.\n"
            "PERSIST OPTIONS\n"
            "                           The persist register controls the N number of time the measurement\n"
            "                           data is outisde the range defined by the upper and lower threshold\n"
            "                           limits before asserting the INT output pin 2.\n"
            "       --ps-persist        Range is from 0 to 15.\n"
            "       --als-persist       Range is from 0 to 15.\n"
            "THRESHOLD OPTIONS\n"
            "                           Threshold determines the upper and lower limit of the interrupt\n"
            "                           threshold value respectively. The two values form a range and the\n"
            "                           interrupt function compares if the measurement value in PS_DATA\n"
            "                           register is inside or outside of the range. The interrupt function\n"
            "                           is active if the measurement data is outisde the range defined by\n"
            "                           the upper and lower limits.\n"
            "       --ps-thres-up       Set upper threshold for PS. Valid range is from 0 to 2047\n"
            "       --ps-thres-low      Set lower threshold for PS. Valid range is from 0 to 2047 \n"
            "       --als-thres-up      Set upper threshold for ALS. Valid range is from 0 to 65535 \n"
            "       --als-thres-low     Set lower threshold for ALS. Valid range is from 0 to 65535\n");
    exit(exit_code);
}
int main(int argc, char **argv){
    
    program_name = argv[0];
    /* Read  program options */
	while(1){
		static struct option long_options[]=
		{
			{"verbose",     no_argument,         &_DEBUG,    1},
			{"help",        no_argument,		    0,		    'h'},
            {"i2c",         required_argument,   0,         'i'},
            {"address",     required_argument,   0,         'a'},
            {"continuously", no_argument,       &_Cont,         1},
            /*
             * Threshold options
             */
             {"ps-thres-up",    required_argument,  0,  0},
             {"ps-thres-low",   required_argument,  0,  0},
             {"als-thres-up",   required_argument,  0,  0},
             {"als-thres-low",  required_argument,  0,  0},
             /*
              * Persist options
              */
             {"ps-persist",		required_argument,	0,	0},
             {"als-persist",	    required_argument,	0,	0},
             /*
              * Interrupt options
              */
             {"int-polarity",	required_argument,	0,	0},
             {"int-mode",       required_argument,  0,  0},
             /*
              * Proximity sensor options
              */
             {"ps-gain",        required_argument,  0,  0},
             {"ps-mode",        required_argument,  0,  0},
             {"ps-led-freq",    required_argument,  0,  0},
             {"ps-led-duty",    required_argument,  0,  0},
             {"ps-led-current", required_argument,  0,  0},
             {"ps-led-pulses",  required_argument,  0,  0},
             {"ps-measurement-rate",    required_argument,  0,  0},
             /*
              * Light sensor options
              */
              {"als-gain",      required_argument,  0,  0},
              {"als-mode",      required_argument,  0,  0},
              {"als-integration-time",  required_argument,  0,  0},
              {"als-measurement-rate",  required_argument,  0,  0},
			{0,		0, 			0,		0}
		};

		int option_index = 0;
		int c = getopt_long(argc, argv, "hi:a:", long_options, &option_index);

		if (c == -1)
		{
			break;
		}

		switch(c)
		{
            case 0:          
               
                if(long_options[option_index].flag != 0)
                    break;
                
                /* Check ALS_GAIN */
                if(!strcmp(long_options[option_index].name, "als-gain")){
                    if(!strcmp(optarg, "1")){
                        reg[ALS_CONTR].value |= 0x08;
                        if(_DEBUG)
                            printf("Setting Dynamic Range 1...[ %sOK%s]\n", GREEN, ESC);
                    }
                    else if(!strcmp(optarg, "0")){
                        reg[ALS_CONTR].value &= ~0x08;
                        if(_DEBUG)
                            printf("Setting Dynamic Range 2...[ %sOK%s]\n", GREEN, ESC);
                    }
                    else{
                        printf("%s : Invalid argument %s!\n", long_options[option_index].name, optarg);
                        exit(-1);
                    }
                    break;
                }else
                /* Check ALS_MODE */
                if(!strcmp(long_options[option_index].name, "als-mode")){
                    if(!strcmp(optarg, "ACTIVE")){
                        reg[ALS_CONTR].value |= 0x03;
                        if(_DEBUG)
                            printf("Setting ALS in Active mode...[ %sOK%s]\n", GREEN, ESC);
                    }
                    else if(!strcmp(optarg, "STANDBY")){
                        reg[ALS_CONTR].value &= ~0x03;
                        if(_DEBUG)
                            printf("Setting ALS in Standby mode...[ %sOK%s]\n", GREEN, ESC);
                    }
                    else{
                        printf("%s : Invalid argument %s!\n", long_options[option_index].name, optarg);
                        exit(-1);
                    }
                    break;
                }else
                /* Check ALS_INTEGRATION_TIME */
                if(!strcmp(long_options[option_index].name, "als-integration-time")){
                    if(!strcmp(optarg, "100")){
                        reg[ALS_MEAS_RATE].value &= ~0x18;
                        if(_DEBUG)
                            printf("Setting 100ms Integration Time...[ %sOK%s]\n", GREEN, ESC);
                    }
                    else if(!strcmp(optarg, "50")){
                        reg[ALS_MEAS_RATE].value &= ~0x10;
                        reg[ALS_MEAS_RATE].value |= 0x08;
                        if(_DEBUG)
                            printf("Setting 50ms Integration Time...[ %sOK%s]\n", GREEN, ESC);
                    }
                    else if(!strcmp(optarg, "200")){
                        reg[ALS_MEAS_RATE].value &= ~0x08;
                        reg[ALS_MEAS_RATE].value |= 0x10;
                        if(_DEBUG)
                            printf("Setting 200ms Integration Time...[ %sOK%s]\n", GREEN, ESC);
                    }
                    else if(!strcmp(optarg, "400")){
                        reg[ALS_MEAS_RATE].value |= 0x18;
                        if(_DEBUG)
                            printf("Setting 400ms Integration Time...[ %sOK%s]\n", GREEN, ESC);
                    }
                    else{
                        printf("%s : Invalid argument %s!\n", long_options[option_index].name, optarg);
                        exit(-1);
                    }
                    break;
                }else
                /* Check ALS_MEASUREMENT_RATE */
                if(!strcmp(long_options[option_index].name, "als-measurement-rate")){
                    if(!strcmp(optarg, "50")){
                        reg[ALS_MEAS_RATE].value &= ~0x07;
                        if(_DEBUG)
                            printf("Setting 50ms Measurement Rate...[ %sOK%s]\n", GREEN, ESC);
                    }
                    else if(!strcmp(optarg, "100")){
                        reg[ALS_MEAS_RATE].value &= ~0x06;
                        reg[ALS_MEAS_RATE].value |= 0x01;
                        if(_DEBUG)
                            printf("Setting 100ms Measurement Rate...[ %sOK%s]\n", GREEN, ESC);
                    }
                    else if(!strcmp(optarg, "200")){
                        reg[ALS_MEAS_RATE].value &= ~0x05;
                        reg[ALS_MEAS_RATE].value |= 0x02;
                        if(_DEBUG)
                            printf("Setting 200ms Measurement Rate...[ %sOK%s]\n", GREEN, ESC);
                    }
                    else if(!strcmp(optarg, "500")){
                        reg[ALS_MEAS_RATE].value &= ~0x04;
                        reg[ALS_MEAS_RATE].value |= 0x03;
                        if(_DEBUG)
                            printf("Setting 500ms Measurement Rate...[ %sOK%s]\n", GREEN, ESC);
                    }
                    else if(!strcmp(optarg, "1000")){
                        reg[ALS_MEAS_RATE].value &= ~0x03;
                        reg[ALS_MEAS_RATE].value |= 0x04;
                        if(_DEBUG)
                            printf("Setting 1000ms Measurement Rate...[ %sOK%s]\n", GREEN, ESC);
                    }
                    else if(!strcmp(optarg, "2000")){
                        reg[ALS_MEAS_RATE].value |= 0x07;
                        if(_DEBUG)
                            printf("Setting 2000ms Measurement Rate...[ %sOK%s]\n", GREEN, ESC);
                    }
                    else{
                        printf("%s : Invalid argument %s!\n", long_options[option_index].name, optarg);
                        exit(-1);
                    }
                    break;
                }else
                /* Check PS_GAIN */
                if(!strcmp(long_options[option_index].name, "ps-gain")){
                    if(!strcmp(optarg, "1")){
                        reg[PS_CONTR].value &= ~0x0C;
                        if(_DEBUG)
                            printf("Setting PS Gain x1...[ %sOK%s]\n", GREEN, ESC);
                    }
                    else if(!strcmp(optarg, "4")){
                        reg[PS_CONTR].value &= ~0x08;
                        reg[PS_CONTR].value |= 0x04;
                        if(_DEBUG)
                            printf("Setting PS Gain x4...[ %sOK%s]\n", GREEN, ESC);
                    }
                    else if(!strcmp(optarg, "8")){
                        reg[PS_CONTR].value &= ~0x04;
                        reg[PS_CONTR].value |= 0x08;
                        if(_DEBUG)
                            printf("Setting PS Gain x8...[ %sOK%s]\n", GREEN, ESC);
                    }
                    else if(!strcmp(optarg, "16")){
                        reg[PS_CONTR].value |= 0x0C;
                        if(_DEBUG)
                            printf("Setting PS Gain x16...[ %sOK%s]\n", GREEN, ESC);
                    }
                    else{
                        printf("%s : Invalid argument %s!\n", long_options[option_index].name, optarg);
                        exit(-1);
                    }
                    break;
                }else
                /* Check PS_MODE */
                if(!strcmp(long_options[option_index].name, "ps-mode")){
                    if(!strcmp(optarg, "STANDBY")){
                        reg[PS_CONTR].value &= ~0x03;
                        if(_DEBUG)
                            printf("Setting PS in Standby Mode...[ %sOK%s]\n", GREEN, ESC);
                    }
                    else if(!strcmp(optarg, "ACTIVE")){
                        reg[PS_CONTR].value |= 0x03;
                        if(_DEBUG)
                            printf("Setting PS in Active Mode...[ %sOK%s]\n", GREEN, ESC);
                    }
                    else{
                        printf("%s : Invalid argument %s!\n", long_options[option_index].name, optarg);
                        exit(-1);
                    }
                    break;
                }else
                /* Check PS_LED_FREQ */
                if(!strcmp(long_options[option_index].name, "ps-led-freq")){
                    if(!strcmp(optarg, "30")){
                        reg[PS_LED].value &= ~0xE0;
                    }
                    else if(!strcmp(optarg, "40")){
                        reg[PS_LED].value &= ~0xC0;
                        reg[PS_LED].value |= 0x20;
                    }
                    else if(!strcmp(optarg, "50")){
                        reg[PS_LED].value &= ~0xA0;
                        reg[PS_LED].value |= 0x40;
                    }
                    else if(!strcmp(optarg, "60")){
                        reg[PS_LED].value &= ~0x80;
                        reg[PS_LED].value |= 0x60;
                    }
                    else if(!strcmp(optarg, "70")){
                        reg[PS_LED].value &= ~0x60;
                        reg[PS_LED].value |= 0x80;
                    }
                    else if(!strcmp(optarg, "80")){
                        reg[PS_LED].value &= ~0x40;
                        reg[PS_LED].value |= 0xA0;
                    }
                    else if(!strcmp(optarg, "90")){
                        reg[PS_LED].value &= ~0x20;
                        reg[PS_LED].value |= 0xC0;
                    }
                    else if(!strcmp(optarg, "40")){
                        reg[PS_LED].value |= 0xE0;
                    }
                    else{
                        printf("%s : Invalid argument %s!\n", long_options[option_index].name, optarg);
                        exit(-1);
                    }
                    break;
                }else
                /* Check PS_LED_DUTY */
                if(!strcmp(long_options[option_index].name, "ps-led-duty")){
                    if(!strcmp(optarg, "25")){
                        reg[PS_LED].value &= ~0x18;
                    }
                    else if(!strcmp(optarg, "50")){
                        reg[PS_LED].value &= ~0x18;
                        reg[PS_LED].value |= 0x08;
                    }
                    else if(!strcmp(optarg, "75")){
                        reg[PS_LED].value &= ~0x18;
                        reg[PS_LED].value |= 0x10;
                    }
                    else if(!strcmp(optarg, "100")){
                        reg[PS_LED].value |= 0x18;
                    }
                    else{
                        printf("%s : Invalid argument %s!\n", long_options[option_index].name, optarg);
                        exit(-1);
                    }
                    break;
                }else
                /* Check PS_LED_CURRENT */
                if(!strcmp(long_options[option_index].name, "ps-led-current")){
                    if(!strcmp(optarg, "5")){
                        reg[PS_LED].value &= ~0x07;
                    }
                    else if(!strcmp(optarg, "10")){
                        reg[PS_LED].value &= ~0x07;
                        reg[PS_LED].value |= 0x01;
                    }
                    else if(!strcmp(optarg, "20")){
                        reg[PS_LED].value &= ~0x07;
                        reg[PS_LED].value |= 0x02;
                    }
                    else if(!strcmp(optarg, "50")){
                        reg[PS_LED].value &= ~0x07;
                        reg[PS_LED].value |= 0x03;
                    }
                    else if(!strcmp(optarg, "100")){
                        reg[PS_LED].value |= 0x07;
                    }
                    else{
                        printf("%s : Invalid argument %s!\n", long_options[option_index].name, optarg);
                        exit(-1);
                    }
                    break;
                }else
                /* Check PS_LED_PULSES */
                if(!strcmp(long_options[option_index].name, "ps-led-pulses")){
                    uint16_t pulses;
                    pulses = (uint16_t)strtol(optarg, NULL, 0);
                    if(pulses >= 0 && pulses <= 255){
                        reg[PS_N_PULSES].value = (uint8_t)pulses;
                    }else{
                        fprintf(stderr, "Value %d is out of range [0...255]!\n", pulses);
                        exit(-1);
                    }
                    break;
                    
                }else
                /* Check PS_MEASUREMENT_RATE */
                if(!strcmp(long_options[option_index].name, "ps-measurement-rate")){
                    if(!strcmp(optarg, "50")){
                        reg[PS_MEAS_RATE].value &= ~0x0F;
                    }
                    else if(!strcmp(optarg, "70")){
                        reg[PS_MEAS_RATE].value &= ~0x0F;
                        reg[PS_MEAS_RATE].value |= 0x01;
                    }
                    else if(!strcmp(optarg, "100")){
                        reg[PS_MEAS_RATE].value &= ~0x0F;
                        reg[PS_MEAS_RATE].value |= 0x02;
                    }
                    else if(!strcmp(optarg, "200")){
                        reg[PS_MEAS_RATE].value &= ~0x0F;
                        reg[PS_MEAS_RATE].value |= 0x03;
                    }
                    else if(!strcmp(optarg, "500")){
                        reg[PS_MEAS_RATE].value &= ~0x0F;
                        reg[PS_MEAS_RATE].value |= 0x04;
                    }
                    else if(!strcmp(optarg, "1000")){
                        reg[PS_MEAS_RATE].value &= ~0x0F;
                        reg[PS_MEAS_RATE].value |= 0x05;
                    }
                    else if(!strcmp(optarg, "2000")){
                        reg[PS_MEAS_RATE].value &= ~0x0F;
                        reg[PS_MEAS_RATE].value |= 0x07;
                    }
                    else{
                        printf("%s : Invalid argument %s!\n", long_options[option_index].name, optarg);
                        exit(-1);
                    }
                    break;
                }else
                /* Check INT_POLARITY */
                if(!strcmp(long_options[option_index].name, "int-polarity")){
                    if(!strcmp(optarg, "0")){
                        reg[INTERRUPT].value &= ~0x04;
                    }
                    else if(!strcmp(optarg, "1")){
                        reg[INTERRUPT].value |= 0x04;
                    }
                    else{
                        printf("%s : Invalid argument %s!\n", long_options[option_index].name, optarg);
                        exit(-1);
                    }
                    break;
                }else
                /* Check INT_MODE */
                if(!strcmp(long_options[option_index].name, "int-mode")){
                    if(!strcmp(optarg, "NONE")){
                        reg[INTERRUPT].value &= ~0x03;
                        if(_DEBUG)
                            printf("Setting inactive interrupt...[ %sOK%s]\n", GREEN, ESC);
                    }
                    else if(!strcmp(optarg, "PS")){
                        reg[INTERRUPT].value &= ~0x03;
                        reg[INTERRUPT].value |= 0x01;
                        if(_DEBUG)
                            printf("Setting PS interrupt...[ %sOK%s]\n", GREEN, ESC);
                    }
                    else if(!strcmp(optarg, "ALS")){
                        reg[INTERRUPT].value &= ~0x03;
                        reg[INTERRUPT].value |= 0x02;
                        if(_DEBUG)
                            printf("Setting ALS interrupt...[ %sOK%s]\n", GREEN, ESC);
                    }
                    else if(!strcmp(optarg, "BOTH")){
                        reg[INTERRUPT].value |= 0x03;
                        if(_DEBUG)
                            printf("Setting BOTH interrupts...[ %sOK%s]\n", GREEN, ESC);
                    }
                    else{
                        printf("%s : Invalid argument %s!\n", long_options[option_index].name, optarg);
                        exit(-1);
                    }
                    break;
                }else
                /* Check PS_PERSIST */
                if(!strcmp(long_options[option_index].name, "ps-persist")){
                    uint16_t persist;
                    persist = (uint16_t)strtol(optarg, NULL, 0);
                    if(persist >= 0 && persist <=16){
                        reg[INTERRUPT_PERSIST].value &= ~0xF0;
                        reg[INTERRUPT_PERSIST].value |= (uint8_t)(persist << 4);
                    }
                    else{
                        fprintf(stderr, "Value %d is out of range [0...15]!\n", persist);
                        exit(-1);
                    }
                    break;
                }else
                /* Check ALS_PERSIST */
                if(!strcmp(long_options[option_index].name, "als-persist")){
                    uint16_t persist;
                    persist = (uint16_t)strtol(optarg, NULL, 0);
                    if(persist >= 0 && persist <=16){
                        reg[INTERRUPT_PERSIST].value &= ~0x0F;
                        reg[INTERRUPT_PERSIST].value |= (uint8_t)persist;
                    }
                    else{
                        fprintf(stderr, "Value %d is out of range [0...15]!\n", persist);
                        exit(-1);
                    }
                    break;
                }else
                /* Check PS_THRES_UP */
                if(!strcmp(long_options[option_index].name, "ps-thres-up")){
                    uint16_t threshold;
                    threshold = (uint16_t)strtol(optarg, NULL, 0);
                    if(threshold >= 0 && threshold <= 2047){
                        reg[PS_THRES_UP_0].value = (uint8_t)(threshold & 0xFF);
                        reg[PS_THRES_UP_1].value = (uint8_t)(threshold >> 8);
                    }
                    else{
                        fprintf(stderr, "Value %d is out of range [0...2047]!\n", threshold);
                        exit(-1);
                    }
                    break;
                }else
                /* Check PS_THRES_LOW */
                if(!strcmp(long_options[option_index].name, "ps-thres-low")){
                    uint16_t threshold;
                    threshold = (uint16_t)strtol(optarg, NULL, 0);
                    if(threshold >= 0 && threshold <= 2047){
                        reg[PS_THRES_LOW_0].value = (uint8_t)(threshold & 0xFF);
                        reg[PS_THRES_LOW_1].value = (uint8_t)(threshold >> 8);
                    }
                    else{
                        fprintf(stderr, "Value %d is out of range [0...2047]!\n", threshold);
                        exit(-1);
                    }
                    break;
                }else
                /* Check ALS_THRES_UP */
                if(!strcmp(long_options[option_index].name, "als-thres-up")){
                    uint16_t threshold;
                    threshold = (uint16_t)strtol(optarg, NULL, 0);
                    reg[ALS_THRES_UP_0].value = (uint8_t)(threshold & 0xFF);
                    reg[ALS_THRES_UP_1].value = (uint8_t)(threshold >> 8);
                }else
                /* Check ALS_THRES_LOW */
                if(!strcmp(long_options[option_index].name, "als-thres-low")){
                    uint16_t threshold;
                    threshold = (uint16_t)strtol(optarg, NULL, 0);
                    reg[ALS_THRES_LOW_0].value = (uint8_t)(threshold & 0xFF);
                    reg[ALS_THRES_LOW_1].value = (uint8_t)(threshold >> 8);
                    break;
                }else
			case 'h':
				print_usage(0);
				break;
			case 'i':
				device = optarg;
				break;
            case 'a':
                SlaveAddress = (uint8_t)strtol(optarg, NULL, 16);
                break;
			case '?':
				break;

			default:
				break;
		}

	}
    
    if(CheckID() != 0){
        printf("ChipID doesn't match!\n");
        exit(-1);
    }
    
    SendConfiguration();
    
    
    if(_Cont){
        uint16_t p_scale = 1;
        uint16_t als_0 = 0, als_1 = 0;
        uint16_t ps = 0;
        
        while(1){
            uint8_t status;
            Read_Register(ALS_PS_STATUS);
            status = reg[ALS_PS_STATUS].value;
            
            /* ALS DATA */
            if(status & 0x04){
                Read_Register(ALS_DATA_CH1_0);
                Read_Register(ALS_DATA_CH1_1);
                Read_Register(ALS_DATA_CH0_0);
                Read_Register(ALS_DATA_CH0_1);
                
                als_0 = (reg[ALS_DATA_CH0_1].value << 8) | reg[ALS_DATA_CH0_0].value;
                als_1 = (reg[ALS_DATA_CH1_1].value << 8) | reg[ALS_DATA_CH1_0].value;
                if(reg[ALS_CONTR].value & 0x08)
                    p_scale = 200;
                printf("%d\n", als_0);
                printf("%d\n", als_1);
                printf("ALS_0: %.3f lux\n", (als_0 * 1.0) / p_scale);
                printf("ALS_1: %.3f lux\n", (als_1 * 1.0) / p_scale);
            }
            
            /* PS DATA */
            if(status & 0x01){
                Read_Register(PS_DATA_0);
                Read_Register(PS_DATA_1);
                
                ps = (reg[PS_DATA_1].value << 8 ) | reg[PS_DATA_0].value;
                printf("PROXIMITY: %.2f cm\n", 10 - (10.0/2047)*ps);
            }
            usleep(100000);
        }
    }
	return 0;
}
