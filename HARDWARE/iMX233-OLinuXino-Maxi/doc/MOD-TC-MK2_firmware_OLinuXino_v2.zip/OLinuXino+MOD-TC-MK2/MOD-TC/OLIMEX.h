/******************************************************************************/
/* OLIMEX COMMANDS	                                                      */
/******************************************************************************/
#ifndef _OLIMEX_H
#define _OLIMEX_H

#define	SET_TRIS	0x01
#define SET_LAT		0x02
#define	GET_PORT	0x03
#define SET_PU		0x04

#define GET_AN0		0x10
#define GET_AN1		0x11
#define GET_AN2		0x12
#define GET_AN3		0x13
#define GET_AN4		0x14
#define GET_AN5		0x15
#define GET_AN6		0x16
#define GET_AN7		0x17

#define GET_TEMP	0x21

#define CLC1_ON		0x31
#define CLC2_ON		0x32
#define CLCs_ON		0x33
#define CLC1_OFF	0x34
#define CLC2_OFF	0x35
#define CLCs_OFF	0x36

#define SET_REL		0x40

#define SET_ADDRESS	0xB0

#endif