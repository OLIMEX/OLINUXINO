/******************************************************************************/
/* Files to Include                                                           */
/******************************************************************************/

#include <htc.h>           /* Global Header File */
#include <stdint.h>        /* For uint8_t definition */
#include <stdbool.h>       /* For true/false definition */

#include "system.h"        /* System funct/params, like osc/peripheral config */
#include "user.h"          /* User funct/params, such as InitApp */
#include "OLIMEX.h"	   /* OLIMEX LTD Command List*/
#include "i2c.h"
#include "MAX31855.h"

/******************************************************************************/
/* User Global Variable Declaration                                           */
/******************************************************************************/

char ADDRESS;

/******************************************************************************/
/* Main Program                                                               */
/******************************************************************************/

uint8_t main(void)
{
    /* Configure the oscillator for the device */
    ConfigureOscillator();

    /* Initialize I/O and Peripherals for application */
    InitApp();
    InitAddress();
    /* Start the system loop*/
    while(1)
    {

	    StartSystem();
    }
}

