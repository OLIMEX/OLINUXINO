/******************************************************************************/
/*Files to Include                                                            */
/******************************************************************************/

#include <htc.h>           /* HiTech General Includes */
#include <stdint.h>        /* For uint8_t definition */
#include <stdbool.h>       /* For true/false definition */

#include "system.h"

/* Refer to the device datasheet for information about available
oscillator configurations. */
void ConfigureOscillator(void)
{
	//SET THE CLOCK 16MHz
	OSCCONbits.IRCF = 0b1111;
	OSCCONbits.SCS = 0b11;

	while(!OSCSTATbits.HFIOFR);
}
