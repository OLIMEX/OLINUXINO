/******************************************************************************/
/* Files to Include                                                           */
/******************************************************************************/

#include <htc.h>            /* HiTech General Includes */
#include <stdint.h>         /* For uint8_t definition */
#include <stdbool.h>        /* For true/false definition */

#include "user.h"
#include "i2c.h"
#include "OLIMEX.h"
#include "MAX31855.h"

/******************************************************************************/
/* User Functions                                                             */
/******************************************************************************/

/* <Initialize variables in user.h and insert code for user algorithms.> */

void InitApp(void)
{

	
    /* Setup analog functionality and port direction */
	ANSELC = 0x00;
	ANSELA = 0x00;

	SCL_TRIS = 1;
	SDA_TRIS = 1;
	SCL_LAT = 0;
	SDA_LAT = 0;

	InitSPI();

	OPTION_REGbits.nWPUEN = 0;
	WPUAbits.WPUA = 0;
	JMP_TRIS = 1;
	JMP_LAT = 0;
	



    /* Initialize peripherals */

    /* Enable interrupts */
}
void InitAddress(void)
{
	char address;
	/* READ THE JUMPER*/
	JMP_TRIS = 1;
	WPUAbits.WPUA5 = 1;
	if(!JMP_PORT)
	{
		/* SET ADDRESS FOR PROGRAMMING*/
		ADDRESS = 0xF0;
	}
	else
	{
		address = ReadFlash(ADDR_MEM);
		/* IF THE MEMORY CELL IS EMPTY*/
		if (address == 0xFF)
		{
			ADDRESS = ADDR_DFL;
		}
		else
		{
			ADDRESS = address;
		}
	}
	
}
char ReadFlash(short address)
{
	char data = 0;
	PMADRL = address & 0x00FF;
	address >>= 8;
	PMADRH = address & 0x00FF;
	PMCON1bits.CFGS = 0;
	PMCON1bits.RD = 1;
	Nop();
	Nop();

	data = PMDATL;
	return data;
}
void EraseFlash(short address)
{
	GIE = 0;
	PMADRL = address & 0x00FF;
	address >>= 8;
	PMADRH = address & 0x00FF;
	PMCON1bits.CFGS = 0;
	PMCON1bits.FREE = 1;
	PMCON1bits.WREN = 1;
	UnlockFlash();
	PMCON1bits.WREN = 0;
	GIE = 1;
}
void UnlockFlash(void)
{
	PMCON2 = 0x55;
	PMCON2 = 0xAA;
	PMCON1bits.WR = 1;
	Nop();
	Nop();
}
void WriteFlash(short data, short address)
{
	GIE = 0;
	PMCON1bits.CFGS = 0;
	PMADRL = address & 0x00FF;
	address >>= 8;
	PMADRH = address & 0x00FF;
	PMCON1bits.FREE = 0;
	PMCON1bits.LWLO = 1;
	PMCON1bits.WREN = 1;
	PMDATL = data & 0x00FF;
	data >>= 8;
	PMDATH = data & 0x00FF;
	PMCON1bits.LWLO = 0;
	UnlockFlash();
	PMCON1bits.WREN = 0;
	GIE = 1;
}
void CommandSetTris(unsigned char data)
{

	GPIO0_TRIS = data & 0x01;
	data >>= 1;
	GPIO1_TRIS = data & 0x01;
	data >>= 1;
	GPIO2_TRIS = data & 0x01;
	data >>= 1;
	GPIO3_TRIS = 1;
	data >>= 1;
	GPIO4_TRIS = data & 0x01;
	data >>= 1;
	GPIO5_TRIS = data & 0x01;
	data >>= 1;
	GPIO6_TRIS = data & 0x01;

}
void CommandSetLat(unsigned char data)
{

	GPIO0_LAT = data & 0x01;
	data >>= 1;
	GPIO1_LAT = data & 0x01;
	data >>= 1;
	GPIO2_LAT = data & 0x01;
	data >>= 1;
//	GPIO3_LAT = command & 0x01;	GPIO3 is ALWAYS INPUT!!!
	data >>= 1;
	GPIO4_LAT = data & 0x01;
	data >>= 1;
	GPIO5_LAT = data & 0x01;
	data >>= 1;
	GPIO6_LAT = data & 0x01;

}
void CommandGetPort(void)
{
	char company;
	char data;
	StopI2C();
	StartI2C();
	company = ReadByteI2C();
	company >>= 1;

	if (company == OLIMEX)
	{
		SendAck();
		data = 0;
		data = GPIO6_PORT & 0x01;
		data <<= 1;
		data |= GPIO5_PORT & 0x01;
		data <<= 1;
		data |= GPIO4_PORT & 0x01;
		data <<= 1;
		data |= GPIO3_PORT & 0x01;
		data <<= 1;
		data |= GPIO2_PORT & 0x01;
		data <<= 1;
		data |= GPIO1_PORT & 0x01;
		data <<= 1;
		data |= GPIO0_PORT & 0x01;

		WriteByteI2C(data);
	}
	else
		SendNack();


}
void CommandGetTemp(void)
{
	char company;
	long int temp = 0;
	StopI2C();
	temp = ReadDataSPI();

	StartI2C();
	company = ReadByteI2C();
	company >>= 1;

	if (company == OLIMEX)
	{
		SendAck();
	/*DOING SOME CLOCK STRETCHING :) */
	
//	SCL_TRIS = 0;
//	SCL_TRIS = 1;
//	WriteLongI2C(0x12345678);
		//0x12345678
	WriteByteI2C(temp & 0x00FF);
	temp >>= 8;
	SendNack();
	//0x123456
	WriteByteI2C(temp & 0x00FF);
	temp >>= 8;
	SendNack();
	//0x1234
	WriteByteI2C(temp & 0x00FF);
	temp >>= 8;
	SendNack();
	//0x12
	WriteByteI2C(temp & 0x00FF);
	SendNack();
	}
	else
		SendNack();

}
void CommandSetPullUps(unsigned char data)
{
	WPUAbits.WPUA0 = data & 0x01;
	data >>= 1;
	WPUAbits.WPUA1 = data & 0x01;
	data >>= 1;
	WPUAbits.WPUA2 = data & 0x01;
	data >>= 1;
	WPUAbits.WPUA3 = data & 0x01;
	data >>= 1;
	WPUAbits.WPUA5 = data & 0x01;
	data >>= 1;

}
void CommandSetAddress(unsigned char data)
{

	/* STORE THE NEW ADDRESS INTO THE FLASH MEMORY */
	EraseFlash(ADDR_MEM);
	WriteFlash(data, ADDR_MEM);
	ADDRESS = data;

}
void CommandGetAn(char channel)
{
	char company;

	StopI2C();

	/* PORT INIT */

	switch(channel)
	{
	case 0:
	{
		TRISAbits.TRISA0 = 1;
		ANSELAbits.ANSA0 = 1;
	} break;
	case 1:
	{
		TRISAbits.TRISA1 = 1;
		ANSELAbits.ANSA1 = 1;
	} break;
	case 2:
	{
		TRISAbits.TRISA2 = 1;
		ANSELAbits.ANSA2 = 1;
	} break;
	case 6:
	{
		TRISCbits.TRISC2 = 1;
		ANSELCbits.ANSC2 = 1;
	} break;

	case 7:
	{
		TRISCbits.TRISC3 = 1;
		ANSELCbits.ANSC3 = 1;
	} break;



	default: break;
	}


	/*CONFIG ADC*/
	ADCON1bits.ADFM = 1;
	ADCON1bits.ADCS = 0;
	ADCON1bits.ADPREF = 0;
	ADCON0bits.CHS = channel;
	ADCON0bits.ADON = 1;

	ADCON0bits.ADGO = 1;
	while(ADCON0bits.ADGO) ;
/*
	result = ADRESH;
	result << = 8;
	result |= ADRESL;
*/

	StartI2C();
	company = ReadByteI2C();
	company >>= 1;
	if (company == OLIMEX)
	{
		SendAck();
	//	WriteWordI2C(result);
		WriteByteI2C(ADRESL);
		SendNack();
		WriteByteI2C(ADRESH);
		SendNack();
	}
	else
		SendNack();

}

void StartSystem(void)
{
	unsigned char company, device, address, command, data;
	_STATUS = _FOO;
    /*Loop until START condition is recieved*/
    StartI2C();

     /*Read the first bit of the address*/
    company = ReadByteI2C();
    company >>= 1;


    if (company == OLIMEX)
    {
	    SendAck();

	    /*Read the second bit of the address*/
	    device = ReadByteI2C();
	    if (device == MOD_TC)
	    {
		    SendAck();

		    /*Read the third bit of the address*/
		    address = ReadByteI2C();
		    if(ADDRESS == address)
		    {


			    SendAck();

			    command = ReadByteI2C();
			    SendAck();

			    if(GET_TEMP == command)
				    CommandGetTemp();
			    else if(SET_PU == command)
			    {
				    data = ReadByteI2C();
				    SendAck();
				    _STATUS = _PU;
			    }
			    else if(SET_ADDRESS == command)
			    {
				    data = ReadByteI2C();
				    SendAck();
				    _STATUS = _ADDRESS;
			    }
			    else if(SET_TRIS == command)
			    {
				    data = ReadByteI2C();
				    SendAck();
				    _STATUS = _TRIS;
			    }
			    else if(SET_LAT == command)
			    {
				    data = ReadByteI2C();
				    SendAck();
				    _STATUS = _LAT;
			    }
			    else if(GET_PORT == command)
				    CommandGetPort();
			    else if(GET_AN0 == command)
				    CommandGetAn(0);
			    else if(GET_AN1 == command)
				    CommandGetAn(1);
			    else if(GET_AN2 == command)
				    CommandGetAn(2);
			    else if(GET_AN6 == command)
				    CommandGetAn(6);
			    else if(GET_AN7 == command)
				    CommandGetAn(7);
			    else
				    SendNack();
		    }
		    else
			    SendNack();
	    }
	    else
		    SendNack();

    }
    else
	    SendNack();
    /*Wait for STOP condition*/
    StopI2C();


    switch(_STATUS)
    {
    case _TRIS: CommandSetTris(data);		break;
    case _LAT:	CommandSetLat(data);		break;
    case _PU:	CommandSetPullUps(data);	break;
    case _ADDRESS:CommandSetAddress(data);	break;
    default: break;
    }


    }



