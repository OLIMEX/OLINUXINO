Tested with openocd-0.6.0-dev-120229143915 and ARM-USB-TINY-H. 
If you have a different debugger use different than the provided 
.cfg for debugger.

Remember that you need libUSB drivers for our programmers to work
with openOCD, not FTDI ones.

Check the following links for guides:

https://www.olimex.com/dev/soft/arm/JTAG/Manual_TELNET.pdf

https://www.olimex.com/dev/soft/arm/JTAG/Manual_PROGRAMMER.pdf

https://www.olimex.com/dev/arm-usb-tiny-h.html

July 2012
Lub/OLIMEX