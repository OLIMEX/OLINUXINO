#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
#  MSH.py
#  
#  Copyright 2013 OLIMEX LTD <support@olimex.com>
#  
#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2 of the License, or
#  (at your option) any later version.
#  
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#  
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
#  MA 02110-1301, USA.

import cv
import cv2
import optparse
import sys
import A13_GPIO as GPIO

mouth_cascade_name   =   "cascades/haarcascade_mcs_mouth.xml"
eyes_cascade_name    =   "cascades/haarcascade_mcs_eyepair_big.xml"
face_cascade_name    =   "cascades/haarcascade_frontalface_alt.xml"


def main():
    
    #get options from command line
    usage = "usage: %prog [options] arg1 ...."
    parser = optparse.OptionParser(usage = usage)
    parser.add_option("-v", "--verbose", action="store_true",
						dest="verbose", default=False,
						help="Print extra messages")					
    parser.add_option("-c", "--cam", type="int", dest="cam",
                        default=0,
                        help="Index of video device")					

		

    #parse options
    (options, args) = parser.parse_args()
    
    DEBUG   =   options.verbose
    CAM     =   options.cam
    INDEX   =   0
    
    
    GPIO.init()
    GPIO.setcfg(GPIO.PIN36, GPIO.INP)
        
    #Mouth
    mouth_cascade = cv.Load(mouth_cascade_name)
    
    #Eyes
    eyes_cascade = cv.Load(eyes_cascade_name)
    
    #Face
    face_cascade = cv.Load(face_cascade_name)
    
    #Creating capture from cam
    capture = cv.CaptureFromCAM(CAM)
    
    
    while True:
        cam = cv.QueryFrame(capture)
        
        t = cv.GetTickCount()

        frame = cv.CreateImage((cam.width/2, cam.height/2), cam.depth, cam.channels)
        cv.Resize(cam, frame, cv.CV_INTER_LINEAR)
        frame_gray = cv.CreateImage(cv.GetSize(frame), 8, 1)
        small_img = cv.CreateImage((cv.Round(frame.width / 2),
                                    cv.Round (frame.height / 2)), 8, 1)
            
        cv.CvtColor( frame, frame_gray, cv.CV_BGR2GRAY )
        
        cv.Resize(frame_gray, small_img, cv.CV_INTER_LINEAR)
        cv.EqualizeHist(small_img, small_img)
        

        
    
        if(INDEX==1 or INDEX==0):
            eyes = cv.HaarDetectObjects(small_img,
                                    eyes_cascade,
                                    cv.CreateMemStorage(0),
                                    1.1,
                                    2, 
                                    0,
                                    (5, 5))
         
        if(INDEX==2):
            faces = cv.HaarDetectObjects(small_img,
                                    face_cascade,
                                    cv.CreateMemStorage(0),
                                    1.1,
                                    2,
                                    0,
                                    (20, 20))
        
        if(INDEX==0):
            mouth = cv.HaarDetectObjects(small_img,
                                    mouth_cascade,
                                    cv.CreateMemStorage(0),
                                    1.1,
                                    20,
                                    0,
                                    (5,5))
            
                                    
        
        if(INDEX == 2):
            if faces:
                for((x, y, w, h), n) in faces:
                    
                    
                    
                    horns = cv.LoadImage("horns.jpg")
               

                    horns_res = cv.CreateImage((w*2, h*2), horns.depth, horns.channels)
                    cv.Resize(horns, horns_res, cv.CV_INTER_LINEAR)         
                    
                    
                    for j in range(horns_res.width):
                        for k in range(horns_res.height):
                            if(k+y*2-h*2) < 0:
                                continue
                            source = cv.Get2D(frame, k + y*2-h*2, j + x*2)
                            over = cv.Get2D(horns_res, k, j)
                        
                            marged = [0]*4
                            
                            if( int(over[0])> 250 and int(over[1]) > 250 and int(over[2]) > 250 and int(over[3]) == 0):
                                for i in range(4):
                                    marged[i] = source[i]
                            else:
                                for i in range(4):
                                    marged[i] = over[i]
                          
                            cv.Set2D(frame, k + y*2 - h*2, j + x*2, marged)
            
        
        elif(INDEX == 0):
            if mouth and eyes:
                for((x, y, w, h), n) in mouth:
                    ((x1, y1, w1, h1), n1) =  eyes[0]
                    
                    if(y < y1):
                        continue
                        
                   
                    
                    mustache = cv.LoadImage("Mustache.jpg")
               

                    mustache_res = cv.CreateImage((w*2, h*2), mustache.depth, mustache.channels)
                    cv.Resize(mustache, mustache_res, cv.CV_INTER_LINEAR)         
                    
                    
                    for j in range(mustache_res.width):
                        for k in range(mustache_res.height):
                            source = cv.Get2D(frame, k + y*2 - int(h*1), j + x*2)
                            over = cv.Get2D(mustache_res, k, j)
                        
                            marged = [0]*4
                            
                            if( int(over[0])== 254 and int(over[1]) == 254 and int(over[2]) == 254 and int(over[3]) == 0):
                                for i in range(4):
                                    marged[i] = source[i]
                            else:
                                for i in range(4):
                                    marged[i] = over[i]
                          
                            cv.Set2D(frame, k + y*2 - int(h*1), j + x*2, marged)   
            
            
                
        elif(INDEX == 1):
            if eyes:
                for ((x, y, w, h), n) in eyes:
                    
                    
                    glasses = cv.LoadImage("glasses.jpg")   
                    glasses_res = cv.CreateImage((w*2, h*2), glasses.depth, glasses.channels)            
                    cv.Resize(glasses, glasses_res, cv.CV_INTER_LINEAR)

                    if(DEBUG):
                        print("Overlaying glasses")
                           

                      
                    for j in range(glasses_res.width):
                        for k in range(glasses_res.height):
                            source = cv.Get2D(frame, k+(y*2), j+(x*2))
                            over = cv.Get2D(glasses_res, k, j)
                            marged = [0]*4
                            
                            if( int(over[0])== 255 and int(over[1]) == 255 and int(over[2]) == 255 and int(over[3]) == 0):
                                for i in range(4):
                                    marged[i] = source[i]
                            else:
                                for i in range(4):
                                    marged[i] = over[i]
                          
                            cv.Set2D(frame, k+y*2, j+x*2, marged)
              
               
        
        
        t = cv.GetTickCount() - t
        print "detection time = %gms" % (t/(cv.GetTickFrequency()*1000.))
        
        cv.ShowImage("result", frame)
        k = cv.WaitKey(10)
        if k % 0x100 == 27:
            break
        
        
        if(GPIO.input(GPIO.PIN36)):
            INDEX+=1;
            if(INDEX == 3):
                INDEX = 0
        
            while(GPIO.input(GPIO.PIN36)):
                pass
        
    
    
    return 0

if __name__ == '__main__':
	main()

