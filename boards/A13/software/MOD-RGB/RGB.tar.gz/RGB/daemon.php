<?php
ignore_user_abort(TRUE);
set_time_limit(0);
ini_set('display_errors', TRUE);

include_once 'rgb.php';

$cycle = $_GET['cycle'];
$duty = $_GET['duty'];
$per = $duty/100;
$delay = $cycle*1000;
$on = (int)($delay)*$per;
$off = (int)($delay - $on);
$count = (int)$_GET['count'];

echo '------------'."\n";
echo 'cycle: '.($cycle/1000)." ms\n";
echo 'duty: '.$duty."%\n";
echo 'per: '.$per."\n";
echo 'delay: '.($delay/1000)." ms\n";
echo 'on: '.($on/1000)." ms\n";
echo 'off: '.($off/1000)." ms\n";
echo 'count: '.$count."\n";


for($i = 0; $i < $count; $i++) {
    if($duty != 100){
        stop();
        usleep($off);
    }
    if($duty != 0){
        start();
        usleep($on);
    }
}

