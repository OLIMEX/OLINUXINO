<?php

if (isset($_GET['f']) && function_exists($_GET['f'])) {
    call_user_func($_GET['f']);
}

function color() {    
    $cmd = './a.out -w '.$_GET['i'].' 0x48 6 0x05 '.$_GET['a'].' 0x03 '.$_GET['r'].' '.$_GET['g'].' '.$_GET['b'];
    echo $cmd."\n";
    exec($cmd);    
    
}

function start() {
    $cmd = './a.out -w '.$_GET['i'].' 0x48 3 0x05 '.$_GET['a'].' 0x01';
    echo $cmd."\n";
    exec($cmd);
}

function stop() {
    $cmd = './a.out -w '.$_GET['i'].' 0x48 3 0x05 '.$_GET['a'].' 0x02';
    echo $cmd."\n";
    exec($cmd);
}
